# 面试复盘助手

AI 驱动的面试录音分析工具，帮助求职者系统性复盘面试表现、发现改进方向。

## 功能特性

- **录音转写** — 支持 MiMo-V2.5-ASR、Groq Whisper 等语音识别服务，自动将面试录音转为文字
- **AI 智能分析** — 接入 OpenAI 兼容 LLM，自动识别问答结构、评估回答质量、生成改进建议
- **JD 关联评估** — 上传职位描述，AI 结合岗位要求进行针对性分析
- **规律分析** — 跨多场面试提取高频考点和共性弱点，支持按公司/岗位筛选
- **自定义标签** — 自由定义岗位方向标签，动态筛选面试记录
- **数据管理** — 服务端文件存储，支持自定义存储路径、导入导出

## 技术架构

```
浏览器 (原生 HTML/CSS/JS)
    ↓
Python HTTP Server (静态文件 + API 代理 + 数据存储)
    ↓
外部 AI 服务 (LLM / ASR)
```

- **前端**：原生 JavaScript，CSS Grid 响应式布局，无框架依赖
- **后端**：Python 标准库 `http.server`，零外部依赖
- **存储**：JSON 文件存储，每场面试独立文件
- **API 代理**：内置 CORS 代理，转发请求至 LLM/ASR 服务

## 快速开始

### 环境要求

- Python 3.7+
- 现代浏览器（Chrome / Edge / Firefox）

### 启动

```bash
cd app
python server.py
```

浏览器访问 `http://localhost:8080`

### 配置

1. 进入 **设置** 页面
2. 配置 **数据存储路径**（服务端保存面试数据的目录）
3. 配置 **面试分析 AI**（OpenAI 兼容接口）
4. （可选）配置 **录音转文字 AI**（Whisper 兼容接口或 MiMo ASR）

#### 支持的 AI 服务

| 用途 | 支持的服务 |
|------|-----------|
| 面试分析 | MiMo、DeepSeek、通义千问、Ollama 等 OpenAI 兼容接口 |
| 语音转写 | MiMo-V2.5-ASR、Groq Whisper、本地 Whisper、通义听悟 |

## 使用方式

1. **上传面试** — 选择录音文件或直接粘贴转写文本，填写公司、岗位、轮次等信息
2. **查看分析** — AI 自动识别每个问题，评估回答优劣，给出改进建议
3. **规律分析** — 积累多场面试后，分析高频考点和反复出现的薄弱环节
4. **持续改进** — 根据分析结果针对性准备，提升面试表现

## 项目结构

```
app/
├── server.py          # Python 服务端（静态文件 + API 代理 + 数据存储）
├── index.html         # 单页应用入口
├── css/
│   └── main.css       # 样式
└── js/
    ├── app.js         # 应用主逻辑（路由、渲染、交互）
    ├── db.js          # 数据层（fetch API 调用服务端存储）
    ├── analyzer.js    # AI 分析模块（LLM 调用 + 基础文本解析）
    ├── whisper.js     # 语音转写模块（MiMo ASR + Whisper 协议）
    └── audio.js       # 音频处理工具
```

## 设计文档

```
prd/                   # 产品需求文档
prototype/             # 高保真交互原型
flowcharts/            # 业务流程图（Mermaid）
```

## License

MIT
